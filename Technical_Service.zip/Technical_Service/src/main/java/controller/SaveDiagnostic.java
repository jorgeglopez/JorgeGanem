package controller;


public class SaveDiagnostic {


}
