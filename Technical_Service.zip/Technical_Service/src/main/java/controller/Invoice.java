package controller;

public class Invoice {

    int TotalValue;

}
