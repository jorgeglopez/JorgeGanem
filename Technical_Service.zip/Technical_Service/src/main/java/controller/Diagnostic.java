package controller;

public class Diagnostic {

    public String status;
    public String observation;

    public Diagnostic(String status, String observation) {
        this.status="Fail";
        this.observation="not repair";



    }
}
