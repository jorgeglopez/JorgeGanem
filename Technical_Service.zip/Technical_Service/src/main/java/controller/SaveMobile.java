package controller;

public class SaveMobile {
    Mobile mobile;

    public void createMobile(){
        mobile =new Mobile(1215151,"Samsung","S10 PLUS","Error General");
    }
}
